# Make it 
make && ./ExtendedKF ../data/sample-laser-radar-measurement-data-1.txt output.txt

